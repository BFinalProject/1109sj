<template>
  <div class="header navbar-fixed-top2">
    <div class="container2">
      <div class="row2">
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <a href="index.html"><img src="../src/assets/UserLogin/images/logo.png" /></a>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
          <div class="navigation">
            <div id="navigation">
              <ul>
                <li class="active">
                  <a href="index.html" title="Home">홈</a>
                </li>
                <li class="active">
                  <a href="#intro" title="Home">소개</a>
                </li>
                <li class="active">
                  <a href="#use" title="Home">이용방법</a>
                </li>
                <li class="active">
                  <a href="index.html" title="Home">게시판</a>
                </li>
                
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="container" id="container">

    <div class="form-container sign-up-container">

      <form action="#">
        <h1>회원가입하기</h1>
        <div class="social-container">
        </div>


        
        <div class="logins" >
          성별&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1"
              style="padding-right: 5px; padding-left: 5px; padding-top: 5px; padding-bottom: 5px;">
            <label class="form-check-label" for="inlineRadio1">남자</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2"
              style="padding-right: 5px; padding-left: 5px; padding-top: 5px; padding-bottom: 5px;">
            <label class="form-check-label" for="inlineRadio2">여자</label>
          </div>
        </div>

        <input type="text" placeholder="이름" />
        <input type="email" placeholder="아이디" />

        <input type="password" id="password1" onchange="passwordreconfirm()" placeholder="비밀번호" />
        <span id="pwConfirm" style="display: none;" >입력한 글자가 6글자 이상이어야 합니다.</span>

        <input type="password" id="password2" onchange="passwordreconfirm()" placeholder="비밀번호확인" />
        <!-- <span id="re" name="password2" onchange="alert(passwordreconfirm())"></span> -->
        <!-- onchange="alert(passwordreconfirm())" -->

        <span id="pwConfirm2" style="display: none;" >비밀번호가 불일치 합니다.</span>
        <span id="pwConfirm3" style="display: none;" >비밀번호가 일치 합니다.</span>
      

        <input type="email" placeholder="이메일" />
        <input type="tel" placeholder="휴대폰번호" /> 
        <button type="button" class="button1">회원가입하기</button>

      </form>
    </div>
    <div class="form-container sign-in-container">
      <form action="#">
        <h1>로그인</h1>
        <br>
        <input type="email" placeholder="아이디" />
        <input type="password" placeholder="비밀번호" />
        <a href="#">아이디 혹은 비밀번호를 잊어버리셨나요?</a>

        <div class="login" >
        <button type="button" class="button1" style="margin-bottom: 10px;">로그인</button>

        <button type="button" class="kakao"> <img  src="../src/assets/UserLogin/images/kakao_login_medium_narrow.png"></button>

        </div>

      </form>
    </div>
    <div class="overlay-container">
      <div class="overlay">
        <div class="overlay-panel overlay-left">
          <h1>Welcome Back!</h1>
          <p>To keep connected with us please login with your personal info</p>
          <button type="button" class="button1" id="signIn">Sign In</button>
        </div>
        <div class="overlay-panel overlay-right">
          <h1>Hello, Friend!</h1>
          <p>아이디가 없으신가요?</p>
          <button type="button" class="button1" id="signUp">회원가입하기</button>
        </div>
      </div>
    </div>
  </div>

</template>

<script>

const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

signUpButton.addEventListener('click', () => {
  container.classList.add("right-panel-active");
});

signInButton.addEventListener('click', () => {
  container.classList.remove("right-panel-active");
});

//1. 비밀번호 재확인
//2. 아이디 중복확인



// 비밀번호 재확인
function passwordreconfirm(){
  let p1 = document.getElementById('password1').value;
  let p2 = document.getElementById('password2').value;
  
  if(p1.length < 6) {
    $("#pwConfirm").show();
    return ('입력한 글자가 6글자 이상이어야 합니다.');
}else{
  // alert("비밀번호가 일치합니다");
  $("#pwConfirm").hide();
  
  // return ("비밀번호가 일치합니다");
}

if( p1 != p2 ) {
  // alert("비밀번호불일치");
  $("#pwConfirm2").show();
 
  // return ("비밀번호불일치");
} else{
  // alert("비밀번호가 일치합니다");
  $("#pwConfirm2").hide();
  
  // return ("비밀번호가 일치합니다");
}if( p1 == p2 ) {
  // alert("비밀번호불일치");
  $("#pwConfirm3").show();
 
  // return ("비밀번호불일치");
} else{
  // alert("비밀번호가 일치합니다");
  $("#pwConfirm3").hide();
  
  // return ("비밀번호가 일치합니다");
}
}



//  아이디 중복확인
function updateValue(e) {
  let x = "tkdwns987"
  if (x == e.target.value) {

    console.log("중복된 아이디입니다.")
  }
  else {
    console.log("사용 가능한 아이디 입니다.")
  }

}

export default {

}
</script>

<style>

</style>