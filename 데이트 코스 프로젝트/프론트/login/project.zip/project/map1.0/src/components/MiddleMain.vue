<template>
    <div id="intro" class="space-medium">
      <div class="container">
        <div class="row">
          <div
            class="col-lg-offset-2 col-lg-8 col-md-offset-2 col-md-8 col-sm-12 col-xs-12"
          >
            <div class="mb60 text-center section-title">
              <!-- section title start-->
              <h1>서비스 소개 </h1>
            </div>
            <!-- /.section title start-->
          </div>
        </div>
        <div class="row">
          <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <div class="service-block text-center">
              <!-- service block -->
              <div class="service-img">
                <!-- service img -->
                <a href="service-detail.html" class="imghover"
                  ><img
                    src="../assets/mainboard/images/service-pic-1.jpg"
                    class="img-responsive"
                    alt="Interior Design Website Templates Free Download"
                  />
                </a>
              </div>
              <!-- service img -->
              <div class="service-content">
                <!-- service content -->
                <h2>
                  <a href="service-detail.html" class="title">Interior</a>
                </h2>
                <p>
                  Phasellus hendrerit mauris vitae odio suscip max pimus donec
                  consequat cursus viverra varius natoque penatibus magnis dis
                  parturient.
                </p>
              </div>
              <!-- service content -->
            </div>
            <!-- /.service block -->
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <div class="service-block text-center">
              <!-- service block -->
              <div class="service-img">
                <!-- service img -->
                <a href="service-detail.html" class="imghover"
                  ><img
                  src="../assets/mainboard/images/service-pic-2.jpg"
                    class="img-responsive"
                    alt="Interior Design Website Templates Free Download"
                  />
                </a>
              </div>
              <!-- service img -->
              <div class="service-content">
                <!-- service content -->
                <h2>
                  <a href="service-detail.html" class="title">Exterior</a>
                </h2>
                <p>
                  Donec tempus odio ac dignissim ultricies massa varius natoque
                  penatibus arturient montes, nascetur ridiculus mus aliquam.
                </p>
              </div>
              <!-- service content -->
            </div>
            <!-- /.service block -->
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <div class="service-block text-center">
              <!-- service block -->
              <div class="service-img">
                <!-- service img -->
                <a href="service-detail.html" class="imghover"
                  ><img
                  src="../assets/mainboard/images/service-pic-3.jpg"
                    class="img-responsive"
                    alt="Interior Design Website Templates Free Download"
                  />
                </a>
              </div>
              <!-- service img -->
              <div class="service-content">
                <!-- service content -->
                <h2>
                  <a href="service-detail.html" class="title">Landscape</a>
                </h2>
                <p>
                  Vestibulum diam arcu varius natoque penatibus magnis dis
                  parturient ridiculus mus mollisid iaculis necaliquamd antetiam
                  consequat.
                </p>
              </div>
              <!-- service content -->
            </div>
            <!-- /.service block -->
          </div>
        </div>
      </div>
    </div>
</template>

<script>
export default {
  name: 'MiddleMain',
  setup () {
    return {}
  }
}
</script>

<style lang="scss" scoped>

</style>
