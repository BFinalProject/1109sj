<template>
  <div class="header navbar-fixed-top">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <a href="index.html"><img src="../assets/images/logo.png" /></a>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
          <div class="navigation">
            <div id="navigation">
              <ul>
                <li class="active">
                  <a href="index.html" title="Home">홈</a>
                </li>
                <li class="active">
                  <a href="#intro" title="Home">소개</a>
                </li>
                <li class="active">
                  <a href="#use" title="Home">이용방법</a>
                </li>
                <li class="active">
                  <a href="board.html" title="Home">게시판</a>
                </li>
                <li class="has-sub">
                  <a href="index.html" title="Blog ">로그인</a>
                  <ul>
                    <li>
                      <a href="blog-default.html" title="Blog">로그인</a>
                    </li>
                    <li>
                      <a href="blog-single.html" title="Blog Single ">회원가입</a>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'NavHeader',
  setup () {
    return {}
  }
}
</script>

<style lang="scss" scoped>
</style>
