<template>
  <div>
    <div class="hero-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
            <h1 class="hero-title">
              <strong>데이트 코스추천</strong><br />
              <h2>AI가 추천하는 최적화된 데이트</h2>
            </h1>
            <a href="/kakaomap" class="btn btn-white"
              >시작하기<i class="fa fa-plus"></i
            ></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'TopMain',
  setup () {
    return {}
  }
}
</script>


