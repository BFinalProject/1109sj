
<template>
            <div class="content-wrapper">
                <!-- Main content -->
                <div class="content">
                    <!-- Content Header (Page header) -->
                    <div class="content-header">
                        <div class="header-icon">
                            <i class="pe-7s-way"></i>
                        </div>
                        <div class="header-title">
                            <h1>조직도</h1>
                            <small>부서별 조직도</small>
                            <ol class="breadcrumb">
                                <li><a href="/#/main"><i class="pe-7s-home"></i> Home</a></li>
                                <li><a href="#">GW</a></li>
                                <li class="active"> 조직도</li>
                            </ol>
                        </div>
                    </div> <!-- /. Content Header (Page header) -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="panel panel-bd lobidrag">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <h4> 조직도 </h4>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <p class="well"><strong>Initialization no parameters</strong>
                                                <br /> <code>$('#tree1').treed();</code>
                                            </p>
                                            <ul id="tree1">
                                                <li><a href="#">TECH</a>
                                                    <ul>
                                                        <li>Company Maintenance</li>
                                                        <li>Employees
                                                            <ul>
                                                                <li>Reports
                                                                    <ul>
                                                                        <li>Report1</li>
                                                                        <li>Report2</li>
                                                                        <li>Report3</li>
                                                                    </ul>
                                                                </li>
                                                                <li>Employee Maint.</li>
                                                            </ul>
                                                        </li>
                                                        <li>Human Resources</li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">XRP</a>
                                                    <ul>
                                                        <li>Company Maintenance</li>
                                                        <li>Employees
                                                            <ul>
                                                                <li>Reports
                                                                    <ul>
                                                                        <li>Report1</li>
                                                                        <li>Report2</li>
                                                                        <li>Report3</li>
                                                                    </ul>
                                                                </li>
                                                                <li>Employee Maint.</li>
                                                            </ul>
                                                        </li>
                                                        <li>Human Resources</li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Tree View One</a>
                                                    <ul>
                                                        <li>Company Maintenance</li>
                                                        <li>Employees
                                                            <ul>
                                                                <li>Reports
                                                                    <ul>
                                                                        <li>Report1</li>
                                                                        <li>Report2</li>
                                                                        <li>Report3</li>
                                                                    </ul>
                                                                </li>
                                                                <li>Employee Maint.</li>
                                                            </ul>
                                                        </li>
                                                        <li>Human Resources</li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-md-4">
                                            <p class="well"><strong>Initialization optional parameters</strong>
                                                <br /> <code>$('#tree2').treed({openedClass : 'fa-folder-open', closedClass : 'fa-folder'});</code>
                                            </p>
                                            <ul id="tree2">
                                                <li><a href="#">TECH</a>
                                                    <ul>
                                                        <li>Company Maintenance</li>
                                                        <li>Employees
                                                            <ul>
                                                                <li>Reports
                                                                    <ul>
                                                                        <li>Report1</li>
                                                                        <li>Report2</li>
                                                                        <li>Report3</li>
                                                                    </ul>
                                                                </li>
                                                                <li>Employee Maint.</li>
                                                            </ul>
                                                        </li>
                                                        <li>Human Resources</li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">XRP</a>
                                                    <ul>
                                                        <li>Company Maintenance</li>
                                                        <li>Employees
                                                            <ul>
                                                                <li>Reports
                                                                    <ul>
                                                                        <li>Report1</li>
                                                                        <li>Report2</li>
                                                                        <li>Report3</li>
                                                                    </ul>
                                                                </li>
                                                                <li>Employee Maint.</li>
                                                            </ul>
                                                        </li>
                                                        <li>Human Resources</li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Tree View Four</a>
                                                    <ul>
                                                        <li>Company Maintenance</li>
                                                        <li>Employees
                                                            <ul>
                                                                <li>Reports
                                                                    <ul>
                                                                        <li>Report1</li>
                                                                        <li>Report2</li>
                                                                        <li>Report3</li>
                                                                    </ul>
                                                                </li>
                                                                <li>Employee Maint.</li>
                                                            </ul>
                                                        </li>
                                                        <li>Human Resources</li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-md-4">
                                            <p class="well"><strong>Initialization optional parameters</strong>
                                                <br /> <code>$('#tree3').treed({openedClass:'fa-plus', closedClass:'fa-minus'});</code>
                                            </p>
                                            <ul id="tree3">
                                                <li><a href="#">TECH</a>
                                                    <ul>
                                                        <li>Company Maintenance</li>
                                                        <li>Employees
                                                            <ul>
                                                                <li>Reports
                                                                    <ul>
                                                                        <li>Report1</li>
                                                                        <li>Report2</li>
                                                                        <li>Report3</li>
                                                                    </ul>
                                                                </li>
                                                                <li>Employee Maint.</li>
                                                            </ul>
                                                        </li>
                                                        <li>Human Resources</li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">XRP</a>
                                                    <ul>
                                                        <li>Company Maintenance</li>
                                                        <li>Employees
                                                            <ul>
                                                                <li>Reports
                                                                    <ul>
                                                                        <li>Report1</li>
                                                                        <li>Report2</li>
                                                                        <li>Report3</li>
                                                                    </ul>
                                                                </li>
                                                                <li>Employee Maint.</li>
                                                            </ul>
                                                        </li>
                                                        <li>Human Resources</li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Tree View Five</a>
                                                    <ul>
                                                        <li>Company Maintenance</li>
                                                        <li>Employees 
                                                            <ul>
                                                                <li>Reports
                                                                    <ul>
                                                                        <li>Report1</li>
                                                                        <li>Report2</li>
                                                                        <li>Report3</li>
                                                                    </ul>
                                                                </li>
                                                                <li>Employee Maint.</li>
                                                            </ul>
                                                        </li>
                                                        <li>Human Resources</li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- <footer class="main-footer">
                <div class="pull-right hidden-xs">Adminpix</div>
                <strong>Copyright &copy; 2018</strong> All rights reserved. <i class="fa fa-heart color-green"></i>
            </footer> -->

</template>








<script>
export default {
  data: function() {
    return {
      statList:[],
      nowMonth:"",
    };
  },
  created: function() {
  },
  mounted: function() {
  },
};
</script>
